from django.apps import AppConfig


class WebiboConfig(AppConfig):
    name = 'app'
